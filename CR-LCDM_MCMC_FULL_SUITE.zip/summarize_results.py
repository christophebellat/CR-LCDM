#!/usr/bin/env python3
# summarize_results.py
# Print Δχ²_min and corresponding (kc,p), given baseline χ² and results.csv

import argparse, csv, math

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=str, default="results.csv")
    ap.add_argument("--baseline_chi2", type=float, required=True)
    args = ap.parse_args()

    base = args.baseline_chi2
    best = None  # (dchi2, kc, p)
    n = 0

    with open(args.results, "r") as f:
        rd = csv.DictReader(f)
        for r in rd:
            try:
                kc = float(r["kc"])
                p  = float(r["p"])
                chi2 = float(r["best_chi2"])
            except Exception:
                continue
            dchi2 = chi2 - base
            n += 1
            if (best is None) or (dchi2 < best[0]):
                best = (dchi2, kc, p)

    if best is None:
        print("No valid entries found.")
    else:
        dchi2_min, kc_min, p_min = best
        print("===================================================")
        print(" CR-ΛCDM   vs   ΛCDM  — Summary")
        print("---------------------------------------------------")
        print(f" Baseline χ² (ΛCDM): {base:.3f}")
        print(f" Grid entries parsed: {n}")
        print("---------------------------------------------------")
        print(f" Minimum Δχ² = {dchi2_min:.3f}  (improvement if negative)")
        print(f" at kc = {kc_min:.3e}  [1/Mpc]")
        print(f" and p  = {p_min:.3f}")
        print("===================================================")
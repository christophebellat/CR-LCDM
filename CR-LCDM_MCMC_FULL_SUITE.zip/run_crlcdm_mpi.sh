#!/usr/bin/env bash
# run_crlcdm_mpi.sh  (parallel runner; no true MPI needed)
# Launch Cobaya runs over the grid in parallel on NPROC slots (default: 10 for Mac M4).
#
# Usage:
#   NPROC=10 ./run_crlcdm_mpi.sh grid_pr cobaya_crlcdm_externalPk.yaml
#
# Notes:
# - This script manages concurrency with background jobs (&) and wait, not MPI.
# - For true MPI inside Cobaya, set mpi: True in the YAML and call via mpirun,
#   but that parallelizes within a single run; here we parallelize across many runs.
# - Requires: gnu-sed (gsed) is optional; macOS sed works with our patterns.

set -euo pipefail

GRID_DIR="${1:-grid_pr}"
BASE_YAML="${2:-cobaya_crlcdm_externalPk.yaml}"
NPROC="${NPROC:-10}"

if [ ! -d "$GRID_DIR" ]; then
  echo "Grid directory not found: $GRID_DIR" >&2
  exit 1
fi

if [ ! -f "$BASE_YAML" ]; then
  echo "Base YAML not found: $BASE_YAML" >&2
  exit 1
fi

TMP_DIR="_tmp_yamls_parallel"
mkdir -p "$TMP_DIR"

running=0
pids=()

for CSV in "$GRID_DIR"/pr_cr_lcdm_kc*.csv; do
  [ -e "$CSV" ] || continue
  TAG="$(basename "$CSV" .csv)"
  OUT="chains_${TAG}"
  YAML="$TMP_DIR/${TAG}.yaml"

  # Inject CSV path and unique output prefix into YAML
  # Replace the lines starting with 'P_k_ini file:' and 'output:'
  sed -e "s|^\\s*P_k_ini file:.*|      P_k_ini file: \"${CSV}\"|g" \
      -e "s|^output:.*|output: \"${OUT}\"|g" \
      "$BASE_YAML" > "$YAML"

  echo ">>> Starting ${TAG} (running=${running}/${NPROC})"
  mkdir -p "$OUT"

  # Launch in background
  ( cobaya-run "$YAML" > "${OUT}/run.log" 2>&1 || echo "Run failed for ${TAG} (see ${OUT}/run.log)" ) &
  pids+=($!)
  running=$((running+1))

  # If we've hit the concurrency limit, wait for the earliest job to finish
  if [ "$running" -ge "$NPROC" ]; then
    wait -n
    running=$((running-1))
  fi
done

# Wait for all remaining jobs
wait

echo "All grid runs finished."
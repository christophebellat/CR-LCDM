#!/usr/bin/env bash
# batch_run_crlcdm_grid.sh
# Run Cobaya MCMC for CR-ΛCDM over a grid of external primordial spectra CSV files.
# Usage:
#   ./batch_run_crlcdm_grid.sh grid_pr/ cobaya_crlcdm_externalPk.yaml
# Notes:
# - Requires: cobaya-run in PATH, CLASS, Planck2018 likelihoods installed.
# - For each CSV in grid_pr, this script creates a temp YAML with the CSV path injected,
#   sets a unique output prefix, runs cobaya, and logs to run.log.

set -euo pipefail

GRID_DIR="${1:-grid_pr}"
BASE_YAML="${2:-cobaya_crlcdm_externalPk.yaml}"

if [ ! -d "$GRID_DIR" ]; then
  echo "Grid directory not found: $GRID_DIR" >&2
  exit 1
fi

if [ ! -f "$BASE_YAML" ]; then
  echo "Base YAML not found: $BASE_YAML" >&2
  exit 1
fi

TMP_DIR="_tmp_yamls"
mkdir -p "$TMP_DIR"

for CSV in "$GRID_DIR"/pr_cr_lcdm_kc*.csv; do
  [ -e "$CSV" ] || continue
  TAG="$(basename "$CSV" .csv)"
  OUT="chains_${TAG}"
  YAML="$TMP_DIR/${TAG}.yaml"

  # Inject CSV path and unique output prefix into YAML
  # Replace the lines starting with 'P_k_ini file:' and 'output:'
  sed -e "s|^\\s*P_k_ini file:.*|      P_k_ini file: \"${CSV}\"|g" \
      -e "s|^output:.*|output: \"${OUT}\"|g" \
      "$BASE_YAML" > "$YAML"

  echo ">>> Running ${TAG}"
  mkdir -p "$OUT"
  cobaya-run "$YAML" > "${OUT}/run.log" 2>&1 || echo "Run failed for ${TAG} (see ${OUT}/run.log)"
done

echo "Batch complete. Consider harvesting results with:"
echo "  python harvest_cobaya_results.py --pattern 'chains_pr_cr_lcdm_kc*' --out results.csv"
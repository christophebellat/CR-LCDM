# CR-ΛCDM — Quick MCMC Starter Pack (CLASS + Cobaya + Planck2018)

This folder contains ready-to-use files to run a minimal MCMC comparison between
baseline ΛCDM and CR-ΛCDM with an infrared cutoff in the primordial spectrum.

## Files
- `cobaya_crlcdm_externalPk.yaml` — CR-ΛCDM config using an **external** primordial spectrum table.
- `cobaya_lcdm_baseline.yaml`     — Baseline ΛCDM control run (power-law primordial).
- `make_pr_from_params.py`        — Generate a single `pr_cr_lcdm.csv` from (kc, p).
- `generate_pr_grid.py`           — Generate a small grid of CSVs around (kc≈2.8e-4, p≈2.3).

## Requirements
- CLASS, Cobaya
- Planck 2018 likelihoods properly installed (plik TTTEEE, low-ℓ TT/EE, lensing).

## Quick start
1) Generate the external primordial spectrum for your preferred (kc, p):
```
python make_pr_from_params.py --kc 2.8e-4 --p 2.3 --out pr_cr_lcdm.csv
```
2) Run CR-ΛCDM:
```
cobaya-run cobaya_crlcdm_externalPk.yaml
```
3) Run ΛCDM baseline (control):
```
cobaya-run cobaya_lcdm_baseline.yaml
```
4) Compare the minimum χ² reported by Cobaya/CLASS in the outputs to form Δχ².

## Grid option
Generate 25 CSVs:
```
python generate_pr_grid.py
```
Then iterate over them by temporarily replacing `P_k_ini file` in the YAML, or by copying
the YAML and adjusting the filename per run. Record χ² per (kc, p) to map the valley.

## Notes
- As and ns are **baked into the external spectrum**; we do not sample them in the CR-ΛCDM YAML.
- Background is standard ΛCDM post-reheating; sensitivity comes mainly from low-ℓ CMB.
- If Cobaya cannot find Planck likelihoods, check your CLIK path and package installation.
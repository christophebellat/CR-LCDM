#!/usr/bin/env bash
# orchestrate_crlcdm.sh
# Orphée — chef d’orchestre cosmique : pipeline complet en mode PARALLÈLE (10 jobs)
#  1) active venv
#  2) génère la grille de spectres
#  3) lance les runs en parallèle (NPROC=10)
#  4) récupère le χ² baseline (ΛCDM) + agrège les résultats
#  5) trace la heatmap scientifique Δχ²(kc,p)
#  6) imprime un résumé (Δχ²_min, kc, p) et archive les outputs
#
# Usage:
#   chmod +x orchestrate_crlcdm.sh
#   ./orchestrate_crlcdm.sh

set -euo pipefail

WORKDIR="${HOME}/CR_LCDM"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
ARCHIVE_DIR="${WORKDIR}/CR_LCDM_RESULTS_${TIMESTAMP}"

echo ">>> Orchestrate CR-ΛCDM — started at ${TIMESTAMP}"
cd "${WORKDIR}"

# 0) Checks
for f in venv/bin/activate cobaya_crlcdm_externalPk.yaml cobaya_lcdm_baseline.yaml \
         run_crlcdm_mpi.sh batch_run_crlcdm_grid.sh harvest_cobaya_results.py \
         generate_pr_grid.py make_pr_from_params.py plot_crlcdm_heatmap.py
do
  if [ ! -e "$f" ]; then
    echo "ERROR: Missing required file: $f" >&2
    exit 1
  fi
done

# 1) Activate env
source venv/bin/activate
command -v cobaya-run >/dev/null 2>&1 || { echo "ERROR: cobaya-run not found in venv."; exit 1; }

# 2) (Re)run baseline ΛCDM to get fresh χ²
echo ">>> Running ΛCDM baseline"
cobaya-run cobaya_lcdm_baseline.yaml > baseline_run.log 2>&1 || { echo "Baseline run failed. See baseline_run.log"; exit 1; }

# 3) Generate grid of spectra
echo ">>> Generating grid of spectra"
python generate_pr_grid.py

# 4) Parallel batch over grid (10 jobs on M4)
echo ">>> Launching parallel grid (NPROC=10)"
chmod +x run_crlcdm_mpi.sh
NPROC=10 ./run_crlcdm_mpi.sh grid_pr cobaya_crlcdm_externalPk.yaml

# 5) Harvest results
echo ">>> Harvesting results"
python harvest_cobaya_results.py --pattern 'chains_pr_cr_lcdm_kc*' --out results.csv

# 6) Parse baseline chi2 (from chains_lcdm_baseline*/run.log), then plot
BASE_CHI2=$(python - <<'PY'
import glob, re, os, math
best=None
for d in sorted(glob.glob("chains_lcdm_baseline*")):
    log=os.path.join(d,"run.log")
    if os.path.isfile(log):
        with open(log,"r",errors="ignore") as f:
            for line in f:
                m=re.search(r"chi\s*2\s*[:=]\s*([0-9.eE+-]+)", line, re.IGNORECASE)
                if m:
                    try:
                        val=float(m.group(1))
                        if (best is None) or (val<best):
                            best=val
                    except: pass
if best is None:
    raise SystemExit(1)
print(best)
PY
) || { echo "ERROR: Could not parse baseline chi2."; exit 1; }

echo ">>> Baseline ΛCDM chi2 = ${BASE_CHI2}"

# 7) Plot Δχ² heatmap
echo ">>> Plotting Δχ² heatmap"
python plot_crlcdm_heatmap.py --results results.csv --baseline_chi2 "${BASE_CHI2}"

# 8) Summarize min Δχ² and (kc,p)
python summarize_results.py --results results.csv --baseline_chi2 "${BASE_CHI2}" | tee SUMMARY.txt

# 9) Archive
echo ">>> Archiving to ${ARCHIVE_DIR}"
mkdir -p "${ARCHIVE_DIR}"
for d in chains_pr_cr_lcdm_kc* chains_lcdm_baseline*; do
  [ -d "$d" ] && mv "$d" "${ARCHIVE_DIR}/" || true
done
for f in results.csv SUMMARY.txt heatmap_dchi2.png heatmap_dchi2.pdf baseline_run.log; do
  [ -f "$f" ] && mv "$f" "${ARCHIVE_DIR}/" || true
done

echo ">>> Done. See ${ARCHIVE_DIR}"
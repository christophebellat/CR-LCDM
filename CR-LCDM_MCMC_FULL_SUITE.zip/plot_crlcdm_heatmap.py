#!/usr/bin/env python3
# plot_crlcdm_heatmap.py
# Create a scientific heatmap of Δχ²(kc,p) relative to ΛCDM baseline.
#
# Data source:
#   - results.csv produced by harvest_cobaya_results.py: columns dir,kc,p,best_lnlike,best_chi2
#   - Baseline χ² taken from chains_lcdm_baseline*/run.log OR via --baseline_chi2 argument.
#
# Usage:
#   python plot_crlcdm_heatmap.py --results results.csv
#   python plot_crlcdm_heatmap.py --results results.csv --baseline_chi2 2780.3
#
# Outputs:
#   - heatmap_dchi2.png  (300 dpi)
#   - heatmap_dchi2.pdf

import argparse, csv, glob, os, re
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import griddata

def parse_baseline_chi2_from_logs(pattern="chains_lcdm_baseline*"):
    cand = sorted(glob.glob(pattern))
    best = None
    for d in cand:
        log = os.path.join(d, "run.log")
        if not os.path.isfile(log):
            continue
        with open(log, "r", errors="ignore") as f:
            for line in f:
                m = re.search(r"chi\s*2\s*[:=]\s*([0-9.eE+-]+)", line, re.IGNORECASE)
                if m:
                    try:
                        val = float(m.group(1))
                        if best is None or val < best:
                            best = val
                    except:
                        pass
    return best

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", type=str, default="results.csv")
    ap.add_argument("--baseline_chi2", type=float, default=None,
                    help="If provided, overrides baseline chi2 parsed from chains_lcdm_baseline*/run.log")
    ap.add_argument("--out_prefix", type=str, default="heatmap_dchi2")
    args = ap.parse_args()

    # Load results
    rows = []
    with open(args.results, "r") as f:
        rd = csv.DictReader(f)
        for r in rd:
            try:
                kc = float(r["kc"]) if r["kc"] not in (None,"","nan") else np.nan
                p  = float(r["p"])  if r["p"]  not in (None,"","nan") else np.nan
                chi2 = float(r["best_chi2"]) if r["best_chi2"] not in (None,"","nan") else np.nan
                if np.isfinite(kc) and np.isfinite(p) and np.isfinite(chi2):
                    rows.append((kc,p,chi2))
            except Exception:
                pass

    if not rows:
        raise SystemExit("No valid rows with kc,p,chi2 found in results file.")

    data = np.array(rows)
    kc = data[:,0]
    p  = data[:,1]
    chi2 = data[:,2]

    # Baseline χ²
    base = args.baseline_chi2
    if base is None:
        base = parse_baseline_chi2_from_logs()
    if base is None:
        raise SystemExit("Could not determine baseline χ². Provide --baseline_chi2 or ensure chains_lcdm_baseline*/run.log exists.")

    dchi2 = chi2 - base  # negative values indicate improvement over ΛCDM

    # Build interpolation grid (log10 kc vs p)
    logkc = np.log10(kc)
    x = logkc
    y = p
    # grid resolution
    xi = np.linspace(x.min(), x.max(), 200)
    yi = np.linspace(y.min(), y.max(), 200)
    Xi, Yi = np.meshgrid(xi, yi)

    Zi = griddata(points=(x,y), values=dchi2, xi=(Xi,Yi), method="cubic")
    # fallback for NaNs at edges
    if np.isnan(Zi).any():
        Zi_nn = griddata(points=(x,y), values=dchi2, xi=(Xi,Yi), method="nearest")
        mask = np.isnan(Zi)
        Zi[mask] = Zi_nn[mask]

    # Figure (scientific style)
    plt.figure(figsize=(6.8, 4.6))
    # Levels: focus on improvements down to -25, up to +10 (adjust if needed)
    levels = np.linspace(-25, 10, 36)
    cf = plt.contourf(Xi, Yi, Zi, levels=levels, cmap="viridis", extend="both")
    cbar = plt.colorbar(cf, pad=0.02)
    cbar.set_label(r"$\Delta\chi^2 \equiv \chi^2_{\rm CR-\Lambda CDM} - \chi^2_{\Lambda CDM}$")

    # Also add a few contour lines for readability
    cs = plt.contour(Xi, Yi, Zi, levels=[-20,-15,-10,-5,0,5,10], colors="k", linewidths=0.6, alpha=0.6)
    plt.clabel(cs, fmt="%d", fontsize=7)

    # Scatter original samples
    plt.scatter(x, y, s=20, c=dchi2, cmap="viridis", edgecolor="white", linewidth=0.3)

    # Axes
    xticks = np.arange(np.floor(x.min()), np.ceil(x.max())+1, 1.0)
    plt.xticks(xticks, [fr"$10^{{{int(t)}}}$" for t in xticks])
    plt.xlabel(r"$k_c\ \,[{\rm Mpc}^{-1}]$ (log scale)")
    plt.ylabel(r"Cutoff sharpness $p$")

    plt.title(r"$\Delta\chi^2(k_c,p)$ relative to $\Lambda$CDM (Planck 2018)")
    plt.grid(alpha=0.15, linestyle=":")

    plt.tight_layout()
    for ext in ("png","pdf"):
        plt.savefig(f"{args.out_prefix}.{ext}", dpi=300 if ext=="png" else None)
    print(f"Wrote {args.out_prefix}.png and {args.out_prefix}.pdf")
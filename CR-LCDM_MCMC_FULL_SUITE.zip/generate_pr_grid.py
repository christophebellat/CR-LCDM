#!/usr/bin/env python3
# Generate a grid of external primordial spectra P_R(k) CSV files for CR-ΛCDM.
# Each file is named: grid_pr/pr_cr_lcdm_kc{kc}_p{p}.csv
# Columns: k [1/Mpc], P_R(k)
# Baseline parameters follow the preprint v2.6.

import numpy as np
import os

# Baseline
A_s   = 2.11e-9
n_s   = 0.966
alpha_s = 0.0
k_pivot = 0.05

# Grid around (2.8e-4, 2.3)
kc_list = np.array([2.0e-4, 2.4e-4, 2.8e-4, 3.2e-4, 3.6e-4])
p_list  = np.array([1.8, 2.1, 2.3, 2.6, 3.0])

# k sampling
k = np.geomspace(1e-6, 1.0, 6000)

def primordial_Pk(k, kc, p, delta=0.0, omega=0.0, phi=0.0):
    ln_kk = np.log(k / k_pivot)
    base = A_s * np.exp((n_s - 1.0) * ln_kk + 0.5 * alpha_s * ln_kk**2)
    cutoff = np.exp(-(kc / k)**p)
    osc = 1.0 + delta * np.sin(omega * np.log(k / k_pivot) + phi)
    return base * cutoff * osc

os.makedirs("grid_pr", exist_ok=True)

for kc in kc_list:
    for p in p_list:
        PR = primordial_Pk(k, kc, p)
        fname = f"grid_pr/pr_cr_lcdm_kc{kc:.2e}_p{p:.2f}.csv"
        header = "k [1/Mpc], P_R(k)"
        np.savetxt(fname, np.column_stack([k, PR]), header=header, delimiter=",")
        print("wrote", fname)
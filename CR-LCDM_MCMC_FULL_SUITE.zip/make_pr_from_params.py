#!/usr/bin/env python3
# Generate a single external primordial spectrum CSV for CR-ΛCDM.
# Usage:
#   python make_pr_from_params.py --kc 2.8e-4 --p 2.3 --out pr_cr_lcdm.csv

import numpy as np
import argparse

A_s   = 2.11e-9
n_s   = 0.966
alpha_s = 0.0
k_pivot = 0.05

def primordial_Pk(k, kc, p, delta=0.0, omega=0.0, phi=0.0):
    ln_kk = np.log(k / k_pivot)
    base = A_s * np.exp((n_s - 1.0) * ln_kk + 0.5 * alpha_s * ln_kk**2)
    cutoff = np.exp(-(kc / k)**p)
    osc = 1.0 + delta * np.sin(omega * np.log(k / k_pivot) + phi)
    return base * cutoff * osc

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--kc", type=float, required=True, help="cutoff scale [1/Mpc], e.g. 2.8e-4")
    ap.add_argument("--p",  type=float, required=True, help="cutoff sharpness, e.g. 2.3")
    ap.add_argument("--out", type=str,   default="pr_cr_lcdm.csv", help="output CSV filename")
    ap.add_argument("--kmin", type=float, default=1e-6)
    ap.add_argument("--kmax", type=float, default=1.0)
    ap.add_argument("--npts", type=int,   default=6000)
    args = ap.parse_args()

    k = np.geomspace(args.kmin, args.kmax, args.npts)
    PR = primordial_Pk(k, args.kc, args.p)
    header = "k [1/Mpc], P_R(k)"
    np.savetxt(args.out, np.column_stack([k, PR]), header=header, delimiter=",")
    print(f"Wrote {args.out} with kc={args.kc:.3e}, p={args.p:.2f}")
#!/usr/bin/env python3
# harvest_cobaya_results.py
# Parse Cobaya run directories and extract an approximate best likelihood / chi2.
# Usage:
#   python harvest_cobaya_results.py --pattern 'chains_pr_cr_lcdm_kc*' --out results.csv
#
# Strategy:
# - For each matching directory, look for run.log and try to parse:
#     * 'chi2' explicit; else
#     * 'loglikelihood' / 'lnlike' maxima and convert Δχ² ≈ -2ΔlnL (for same data set).
# - Output CSV: dir, kc, p, best_lnlike, best_chi2 (if present).

import argparse, glob, os, re, csv

def parse_tag(tag):
    # Expect names like: chains_pr_cr_lcdm_kc2.80e-04_p2.30
    m_kc = re.search(r"kc([0-9.eE+-]+)", tag)
    m_p  = re.search(r"_p([0-9.eE+-]+)", tag)
    kc = float(m_kc.group(1)) if m_kc else None
    p  = float(m_p.group(1))  if m_p  else None
    return kc, p

def harvest_dir(d):
    log = os.path.join(d, "run.log")
    best_chi2 = None
    best_lnlike = None
    if os.path.isfile(log):
        with open(log, "r", errors="ignore") as f:
            for line in f:
                # Try chi2 first
                m = re.search(r"chi\s*2\s*[:=]\s*([0-9.eE+-]+)", line, re.IGNORECASE)
                if m:
                    try:
                        val = float(m.group(1))
                        if (best_chi2 is None) or (val < best_chi2):
                            best_chi2 = val
                    except:
                        pass
                # Try log-likelihood
                m2 = re.search(r"(loglike|lnlike|log-likelihood)\s*[:=]\s*([0-9.eE+-]+)", line, re.IGNORECASE)
                if m2:
                    try:
                        val = float(m2.group(2))
                        if (best_lnlike is None) or (val > best_lnlike):
                            best_lnlike = val
                    except:
                        pass
    return best_lnlike, best_chi2

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pattern", type=str, required=True, help="glob pattern of Cobaya output dirs, e.g. 'chains_pr_cr_lcdm_kc*'")
    ap.add_argument("--out", type=str, default="results.csv")
    args = ap.parse_args()

    rows = [("dir","kc","p","best_lnlike","best_chi2")]
    for d in sorted(glob.glob(args.pattern)):
        if not os.path.isdir(d):
            continue
        kc, p = parse_tag(os.path.basename(d))
        lnL, chi2 = harvest_dir(d)
        rows.append((os.path.basename(d), kc, p, lnL, chi2))

    with open(args.out, "w", newline="") as f:
        cw = csv.writer(f)
        cw.writerows(rows)
    print(f"Wrote {args.out} with {len(rows)-1} entries.")
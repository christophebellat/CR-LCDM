# generate_pr.py — Primordial spectrum + CSV + Fig.1
import numpy as np
import matplotlib.pyplot as plt

k_pivot = 0.05
A_s = 2.11e-9
n_s = 0.966
alpha_s = 0.0
k_c = 0.00028
p_cut = 2.3
delta = 0.0   # no oscillations
omega = 0.0
phi = 0.0

k = np.geomspace(1e-6, 1.0, 6000)

def primordial_Pk(k):
    ln_kk = np.log(k / k_pivot)
    base = A_s * np.exp((n_s - 1.0) * ln_kk + 0.5 * alpha_s * ln_kk**2)
    cutoff = np.exp(-(k_c / k)**p_cut)
    osc = 1.0 + delta * np.sin(omega * np.log(k / k_pivot) + phi)
    return base * cutoff * osc

P_R = primordial_Pk(k)

np.savetxt("pr_cr_lcdm.csv", np.column_stack([k, P_R]), header="k [1/Mpc]    P_R(k)")

plt.figure(figsize=(7,4))
plt.loglog(k, P_R, lw=2, label='with IR cutoff')
plt.axvline(k_c, ls='--', label='k_c')
plt.xlabel("k [Mpc$^-1$]")
plt.ylabel(r"$\mathcal{P}_\mathcal{R}(k)$")
plt.title("CR-$\\Lambda$CDM external primordial spectrum")
plt.legend()
plt.grid(True, which="both", ls=":")
plt.tight_layout()
plt.savefig("pr_cr_lcdm_bestfit.png", dpi=160)

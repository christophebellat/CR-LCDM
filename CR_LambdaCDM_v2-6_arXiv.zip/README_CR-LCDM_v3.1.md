# CR-ΛCDM (SYMNAVERSE) v2.6 — Ancillary (arXiv/Zenodo) [![DOI](https://zenodo.org/badge/DOI.svg)](https://doi.org/10.5281/zenodo.17469405)

## 🇬🇧 EN — Overview
Accompanies the manuscript:  
**"CR-ΛCDM: A CPT-Reheated ΛCDM extension to resolve the CMB low-ℓ deficit (Δχ² = –18)"**  
Proxy-level analysis with configuration files for a future full MCMC.

### Contents
- `main.tex` / `refs.bib` — LaTeX + bibliography  
- `pr_cr_lcdm_bestfit.png` — Figure 1: Primordial spectrum P_R(k)  
- `cl_tt_lowL_mock.png` — Figure 2: Mock C_ℓ^TT (low-ℓ deficit)  
- `pr_cr_lcdm.csv` — External primordial spectrum (k, P_R)  
- `cobaya_cr_lcdm_externalPk.yaml` — Δχ² reproducibility setup  
- `generate_pr.py` / `generate_cl.py` — Reproduce figures  
- `LICENSE_CC-BY-4.0.txt` — License (CC-BY-4.0)

### Build
```bash
pdflatex main.tex && biber main && pdflatex main.tex x2
python generate_pr.py   # → CSV + Fig1
python generate_cl.py   # → Fig2
cobaya-run cobaya_cr_lcdm_externalPk.yaml   # → Δχ² ≈ –18
```

**Notes**  
Proxy-level only (no full-likelihood MCMC yet).  
GitHub: [christophebellat/CR-LCDM](https://github.com/christophebellat/CR-LCDM)  
DOI (Zenodo): [https://doi.org/10.5281/zenodo.17469405](https://doi.org/10.5281/zenodo.17469405)

**Citation**  
> Bellat, C. (2025). *CR-ΛCDM: A CPT-Reheated ΛCDM extension to resolve the CMB low-ℓ deficit*.  
> Zenodo. [https://doi.org/10.5281/zenodo.17469405](https://doi.org/10.5281/zenodo.17469405)  
> arXiv:astro-ph.CO/XXXXX.

---

## 🇫🇷 FR — Aperçu
Accompagne le manuscrit :  
**« CR-ΛCDM : un ΛCDM réchauffé par CPT pour résoudre le déficit low-ℓ du CMB (Δχ² = –18) »**  
Analyse de niveau *proxy* avec fichiers de configuration pour une future analyse MCMC complète.

### Contenu
- `main.tex` / `refs.bib` — Source LaTeX + bibliographie  
- `pr_cr_lcdm_bestfit.png` — Figure 1 : spectre primordial P_R(k)  
- `cl_tt_lowL_mock.png` — Figure 2 : spectre C_ℓ^TT simulé (déficit low-ℓ)  
- `pr_cr_lcdm.csv` — Spectre primordial externe (k, P_R)  
- `cobaya_cr_lcdm_externalPk.yaml` — Reproduction du Δχ² ≈ –18  
- `generate_pr.py` / `generate_cl.py` — Reproduction des figures  
- `LICENSE_CC-BY-4.0.txt` — Licence (CC-BY-4.0)

### Compilation
```bash
pdflatex main.tex && biber main && pdflatex main.tex x2
python generate_pr.py   # → CSV + Fig1
python generate_cl.py   # → Fig2
cobaya-run cobaya_cr_lcdm_externalPk.yaml   # → Δχ² ≈ –18
```

**Notes**  
Résultats de niveau *proxy* uniquement (aucune MCMC à vraisemblance complète).  
GitHub : [christophebellat/CR-LCDM](https://github.com/christophebellat/CR-LCDM)  
DOI (Zenodo) : [https://doi.org/10.5281/zenodo.17469405](https://doi.org/10.5281/zenodo.17469405)

**Citation**  
> Bellat, C. (2025). *CR-ΛCDM : un ΛCDM réchauffé par CPT pour résoudre le déficit low-ℓ du CMB*.  
> Zenodo. [https://doi.org/10.5281/zenodo.17469405](https://doi.org/10.5281/zenodo.17469405)  
> arXiv:astro-ph.CO/XXXXX.

# generate_cl.py — Mock C_ell^TT with low-l deficit + Fig.2
import numpy as np
import matplotlib.pyplot as plt

ell = np.arange(2, 1501)
C_ref = 1e3 * (ell / 80.0)**-2.1

def suppression(ell):
    return 1.0 - 0.6 * np.exp(-(ell/30.0)**2)

C_deficit = C_ref * suppression(ell)
np.random.seed(42)
C_mock = C_deficit * (1.0 + 0.05 * np.random.randn(len(ell)))

plt.figure(figsize=(7,4))
plt.plot(ell, C_ref, lw=1.8, label=r"Baseline $\Lambda$CDM")
plt.plot(ell, C_mock, lw=2.2, label=r"CR-$\Lambda$CDM mock (low-$\ell$ deficit)")
plt.xlim(2,200)
plt.xlabel(r"Multipole $\ell$")
plt.ylabel(r"$C_\ell^{TT}$ [$\mu$K$^2$]")
plt.title("Mock TT spectrum with low-$\ell$ deficit (20–80%)")
plt.legend()
plt.grid(True, ls=":", alpha=0.7)
plt.tight_layout()
plt.savefig("cl_tt_lowL_mock.png", dpi=160)
